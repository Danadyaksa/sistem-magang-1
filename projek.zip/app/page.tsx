import { ComponentExample } from "@/components/component-example";

export default function Page() {
return <ComponentExample />;
}